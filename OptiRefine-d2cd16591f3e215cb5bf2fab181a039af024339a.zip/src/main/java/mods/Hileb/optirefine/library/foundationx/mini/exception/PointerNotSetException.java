/*
 * Mini - an ASM-based class transformer reminiscent of MalisisCore and Mixin
 * 
 * The MIT License
 *
 * Copyright (c) 2017-2021 Una Thompson (unascribed) and contributors
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

package mods.Hileb.optirefine.library.foundationx.mini.exception;

import mods.Hileb.optirefine.library.foundationx.mini.PatchContext;

import java.io.Serial;

/**
 * Thrown when the code pointer of a {@link PatchContext} has not yet been set
 * by an absolute operation.
 */
public class PointerNotSetException extends IllegalStateException {
	@Serial
	private static final long serialVersionUID = -3585879222630865802L;

	public PointerNotSetException() {
		super();
	}

	public PointerNotSetException(String message, Throwable cause) {
		super(message, cause);
	}

	public PointerNotSetException(String s) {
		super(s);
	}

	public PointerNotSetException(Throwable cause) {
		super(cause);
	}

}
